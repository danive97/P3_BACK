package com.ufv.userAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
